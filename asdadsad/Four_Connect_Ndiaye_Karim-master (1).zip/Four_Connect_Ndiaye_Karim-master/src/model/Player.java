package model;

public class Player {

    private String playerName;
    private int playerID;


    public Player() {

    }

    public String getPlayerName() {
        return playerName;
    }

    public int getPlayerID() {
        return playerID;
    }
}

